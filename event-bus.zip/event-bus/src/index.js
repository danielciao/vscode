import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

import { eventBusServer } from './event-bus';
import registerServiceWorker from './registerServiceWorker';

eventBusServer.on('connection', function(appId, socket) {
  console.log(`a socket is connected for ${appId}!`);

  socket.on('updateUser', function(user) {
    console.log('updateUser', user);
  });

  socket.onOnce('updateUserOnce', function(user) {
    console.log('updateUserOnce', user);
  });

  socket.on('disconnect', function(appId) {
    console.log(`${appId} disconnected...`);
  });
});

ReactDOM.render(<App />, document.getElementById('root'));
registerServiceWorker();
