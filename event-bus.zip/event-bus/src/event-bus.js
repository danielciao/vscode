const EventType = {
  connection: 'connection',
  disconnect: 'disconnect'
};

class Socket {
  constructor() {
    window.EventBus = window.EventBus || {};
    this.topics = window.EventBus.topics = window.EventBus.topics || {};
  }

  connect(appId) {
    this.emit('connection', appId);
  }

  disconnect(appId) {
    this.emit('disconnect', appId);
  }

  emit(topic, data = {}) {
    if (!this.topics[topic]) {
      return;
    }

    this.topics[topic].forEach(({ callback }) => callback(data));
    this.topics[topic] = this.topics[topic].filter(({ onlyOnce }) => !onlyOnce);
  }

  on(topic, callback) {
    this.topics[topic] = this.topics[topic] || [];

    const index = this.topics[topic].push({ callback }) - 1;

    return function() {
      delete this.topics[topic][index];
    };
  }

  onOnce(topic, callback) {
    this.topics[topic] = this.topics[topic] || [];

    this.topics[topic].push({ callback, onlyOnce: true });
  }
}

export const eventBusClient = function() {
  return new Socket();
};

export const eventBusServer = {
  on: function(eventType, callback) {
    switch (eventType) {
      case EventType.connection:
        const socket = new Socket();
        socket.on(eventType, appId => callback(appId, socket));

        break;

      case EventType.disconnect:
        callback && callback();

      default:
      // do nothing
    }
  }
};
