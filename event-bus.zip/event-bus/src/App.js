import React, { Component } from 'react';
import logo from './logo.svg';
import { eventBusClient } from './event-bus';

import './App.css';

const socket = eventBusClient();

function handleEmitEvent(e) {
  socket.emit('updateUser', { user: 'Daniel' });
}

function handleEmitEventOnce(e) {
  socket.emit('updateUserOnce', { user: 'Daniel' });
}

function handleDisconnect() {
  socket.disconnect('app1');
}

class App extends Component {
  state = {};

  componentDidMount() {
    socket.on('updateUser', ({ user }) => {
      this.setState({
        user
      });
    });

    socket.connect('app1');
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>
        <p>
          <button onClick={handleEmitEvent}>Emit Event</button>
          <button onClick={handleEmitEventOnce}>Emit Event Once</button>
          <button onClick={handleDisconnect}>Disconnect</button>
        </p>
        <p>Hello {this.state.user || 'Anonymous'}!</p>
      </div>
    );
  }
}

export default App;
